<?php

require_once __DIR__ . '/../shared/require-admin.php';

$auth = requireAdmin();

$pdo = $auth['pdo'];

try {

    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = min(100, max(10, (int)($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;

    $action = trim($_GET['action'] ?? '');
    $adminId = (int)($_GET['admin_id'] ?? 0);

    $where = [];
    $params = [];

    if ($action !== '') {
        $where[] = 'al.action = :action';
        $params['action'] = $action;
    }

    if ($adminId > 0) {
        $where[] = 'al.admin_id = :admin_id';
        $params['admin_id'] = $adminId;
    }

    $whereSql = '';

    if (!empty($where)) {
        $whereSql = 'WHERE ' . implode(' AND ', $where);
    }

    $countStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM admin_logs al
        {$whereSql}
    ");

    $countStmt->execute($params);

    $total = (int)$countStmt->fetchColumn();

    $stmt = $pdo->prepare("
        SELECT
            al.id,
            al.action,
            al.entity_type,
            al.entity_id,
            al.old_value,
            al.new_value,
            al.created_at,

            u.id AS admin_id,
            u.full_name,
            u.email

        FROM admin_logs al

        LEFT JOIN users u
            ON u.id = al.admin_id

        {$whereSql}

        ORDER BY al.created_at DESC

        LIMIT :limit OFFSET :offset
    ");

    foreach ($params as $key => $value) {
        $stmt->bindValue(':' . $key, $value);
    }

    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

    $stmt->execute();

    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($items as &$item) {

        if (!empty($item['old_value'])) {
            $item['old_value'] = json_decode($item['old_value'], true);
        }

        if (!empty($item['new_value'])) {
            $item['new_value'] = json_decode($item['new_value'], true);
        }
    }

    adminJsonResponse([
        'success' => true,
        'data' => [
            'items' => $items,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'pages' => (int)ceil($total / $limit),
            ]
        ]
    ]);

} catch (Throwable $e) {

    adminJsonResponse([
        'success' => false,
        'message' => 'Ошибка получения журнала действий',
        'error' => $e->getMessage()
    ],500);

}