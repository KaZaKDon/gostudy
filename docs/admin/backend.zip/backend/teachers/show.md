<?php

require_once __DIR__ . '/../shared/require-moderator.php';

$auth = requireAdminOrModerator();

$pdo = $auth['pdo'];

try {
    $teacherId = (int) ($_GET['id'] ?? 0);

    if ($teacherId <= 0) {
        adminJsonResponse([
            'success' => false,
            'message' => 'Не передан ID преподавателя',
        ], 400);
    }

    $stmt = $pdo->prepare("
        SELECT
            u.id,
            u.full_name,
            u.email,
            u.phone,
            u.status,
            u.created_at,
            u.last_login_at,

            tp.*
        FROM users u
        INNER JOIN teacher_profiles tp
            ON tp.user_id = u.id
        WHERE u.id = :id
        LIMIT 1
    ");

    $stmt->execute([
        'id' => $teacherId,
    ]);

    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        adminJsonResponse([
            'success' => false,
            'message' => 'Преподаватель не найден',
        ], 404);
    }

    $subjectsStmt = $pdo->prepare("
        SELECT
            s.id,
            s.name,
            s.slug
        FROM teacher_subjects ts
        INNER JOIN subjects s
            ON s.id = ts.subject_id
        WHERE ts.teacher_id = :teacher_id
        ORDER BY s.name
    ");

    $subjectsStmt->execute([
        'teacher_id' => $teacherId,
    ]);

    $subjects = $subjectsStmt->fetchAll(PDO::FETCH_ASSOC);

    $documentsStmt = $pdo->prepare("
        SELECT
            id,
            type,
            file_url,
            original_name,
            status,
            reject_reason,
            checked_at,
            created_at
        FROM teacher_documents
        WHERE teacher_id = :teacher_id
        ORDER BY created_at DESC
    ");

    $documentsStmt->execute([
        'teacher_id' => $teacherId,
    ]);

    $documents = $documentsStmt->fetchAll(PDO::FETCH_ASSOC);

    $studentsStmt = $pdo->prepare("
        SELECT
            ts.id,
            ts.student_id,
            u.full_name,
            u.email,
            u.phone
        FROM teacher_students ts
        INNER JOIN users u
            ON u.id = ts.student_id
        WHERE ts.teacher_id = :teacher_id
        ORDER BY u.full_name
    ");

    $studentsStmt->execute([
        'teacher_id' => $teacherId,
    ]);

    $students = $studentsStmt->fetchAll(PDO::FETCH_ASSOC);

    $reviewsStmt = $pdo->prepare("
        SELECT
            r.id,
            r.rating,
            r.text,
            r.status,
            r.created_at,
            u.full_name AS student_name
        FROM reviews r
        INNER JOIN users u
            ON u.id = r.student_id
        WHERE r.teacher_id = :teacher_id
        ORDER BY r.created_at DESC
        LIMIT 20
    ");

    $reviewsStmt->execute([
        'teacher_id' => $teacherId,
    ]);

    $reviews = $reviewsStmt->fetchAll(PDO::FETCH_ASSOC);

    adminJsonResponse([
        'success' => true,
        'data' => [
            'teacher' => $teacher,
            'subjects' => $subjects,
            'documents' => $documents,
            'students' => $students,
            'reviews' => $reviews,
        ],
    ]);
} catch (Throwable $error) {
    adminJsonResponse([
        'success' => false,
        'message' => 'Ошибка получения карточки преподавателя',
        'error' => $error->getMessage(),
    ], 500);
}

