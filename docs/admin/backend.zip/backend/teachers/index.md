<?php

require_once __DIR__ . '/../shared/require-moderator.php';

$auth = requireAdminOrModerator();

$pdo = $auth['pdo'];

try {
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $limit = min(100, max(10, (int) ($_GET['limit'] ?? 20)));
    $offset = ($page - 1) * $limit;

    $verificationStatus = trim($_GET['verification_status'] ?? '');
    $q = trim($_GET['q'] ?? '');

    $where = [
        "u.role = 'teacher'"
    ];

    $params = [];

    if ($verificationStatus !== '') {
        $where[] = 'tp.verification_status = :verification_status';
        $params['verification_status'] = $verificationStatus;
    }

    if ($q !== '') {
        $where[] = '(
            u.full_name LIKE :q
            OR u.email LIKE :q
            OR u.phone LIKE :q
        )';

        $params['q'] = '%' . $q . '%';
    }

    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $countStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM users u
        INNER JOIN teacher_profiles tp ON tp.user_id = u.id
        {$whereSql}
    ");

    $countStmt->execute($params);

    $total = (int) $countStmt->fetchColumn();

    $stmt = $pdo->prepare("
        SELECT
            u.id,
            u.full_name,
            u.email,
            u.phone,
            u.status,
            u.created_at,

            tp.verification_status,
            tp.verification_comment,
            tp.verified_at,
            tp.experience_years,
            tp.hour_price

        FROM users u
        INNER JOIN teacher_profiles tp
            ON tp.user_id = u.id

        {$whereSql}

        ORDER BY u.created_at DESC

        LIMIT :limit OFFSET :offset
    ");

    foreach ($params as $key => $value) {
        $stmt->bindValue(':' . $key, $value);
    }

    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

    $stmt->execute();

    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    adminJsonResponse([
        'success' => true,
        'data' => [
            'items' => $items,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'pages' => (int) ceil($total / $limit),
            ],
        ],
    ]);
} catch (Throwable $error) {
    adminJsonResponse([
        'success' => false,
        'message' => 'Ошибка получения списка преподавателей',
        'error' => $error->getMessage(),
    ], 500);
}